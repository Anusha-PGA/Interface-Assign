package com.heraizen.cj.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ArrayOperations {
	public int getSum(int arr[]) {
		int sum = 0;
		for (int i : arr) {
			sum = sum + i;
		}
		return sum;
	}

	public int getBiggest(int arr[]) {
		Arrays.sort(arr);
		return arr[arr.length - 1];

	}

	public int getSmallest(int arr[]) {
		Arrays.sort(arr);
		return arr[0];
	}

	public int[] getMissingNumber(int arr[]) {
		Arrays.sort(arr);
		List result = new ArrayList();
		for (int i = 0, j=arr[0]; i < arr.length; i++,j++) {
			if (j != arr[i]) {
				result.add(j);
				i--;
			}
		
		}
		int rs[]=new int[result.size()];
		for(int i=0;i<result.size();i++)
		{
			rs[i]=(int) result.get(i);
		}
		return rs;

	}

}
