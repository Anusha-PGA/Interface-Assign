package com.heraizen.cj.arrays;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

public class ArraysOperationTest {

	ArrayOperations obj;

	@BeforeAll
	public static void beforeAll() {
		System.out.println("Before All");
	}

	@AfterAll
	public static void afterAll() {
		System.out.println("After All");
	}

	@AfterEach
	public void afterEach() {
		System.out.println("After Each");
	}

	@BeforeEach
	public void inti() {
		obj = new ArrayOperations();
		System.out.println("Before Each");
	}

	@Nested
	public class sum {
		@Test
		public void GetSumTest() {
			int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
			assertEquals(55, obj.getSum(arr));
		}

		@Test
		@DisplayName("Negative")
		public void GetSumTestNegativeNos() {
			int[] arr = { -1, -2, -3, -4, -5, -6, -7, -8, -9, -10 };
			assertEquals(-55, obj.getSum(arr));
		}
	}

	@Tag("Largest")
	@Test
	public void getBiggestTest() {
		int[] arr = { 4, 2, 8, 12, 5, 1, 7, 3, 6, 9 };
		assertEquals(12, obj.getBiggest(arr));
	}

	@Test
	public void getSmallestTest() {
		int[] arr = { 4, 2, 8, 12, 5, 1, 7, 3, 6, 9 };
		assertEquals(1, obj.getSmallest(arr));
	}

	@Test
	public void getMissingNumberTest() {
		assertAll("Missing Nos",
		()->assertEquals(Arrays.toString(new int[] { 2, 7, 8 }), Arrays.toString(obj.getMissingNumber(new int[]  { 4, 5, 1, 3, 6, 9 }))),
		()->assertEquals(Arrays.toString(new int[] {}), Arrays.toString(obj.getMissingNumber(new int[]  { 4, 2, 5, 7, 8, 1, 3, 6, 9 })))
	);}

	@Test
	@EnabledOnOs({ OS.LINUX })
	public void printOS() {
		System.out.println(System.getProperty("os.name"));
	}

}
