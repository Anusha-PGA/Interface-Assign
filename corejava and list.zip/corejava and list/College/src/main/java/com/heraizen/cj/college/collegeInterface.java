package com.heraizen.cj.college;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;



public interface collegeInterface {
	List<College> getAllColleges();

	List<College> getColleges(Predicate<College> p);
	
	Optional<College> getCollegeByName(String name);
	
	Optional<Integer> totalStudents();
	
	Optional<Integer> totalFaculties();
	
	List <College> sort(Comparator<College> comp);
}
