package com.heraizen.cj.college;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public final class DataReader {
	//public static List<College> Colleges;
	public static List<College> getCollegesFromFile(String fileName){
		List<String> lines=null;
		List<College> Colleges= new ArrayList<College>();
		try{
			lines=Files.readAllLines(Paths.get(fileName));
		}
		catch(IOException e){
			e.printStackTrace();
		}
		for(String line:lines) {
			String[] arr = line.split(",");
			College college = new College(arr[0],Integer.parseInt(arr[1]),Integer.parseInt(arr[2]),Integer.parseInt(arr[3]));
			Colleges.add(college);
		}
		return Colleges;
	}

}
