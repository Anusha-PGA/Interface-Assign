package com.heraizen.cj.college;

public class College {
	private String college;
	private int deptCount;
	private int totalNoOfStudents;
	private int totalNoOfFaculties;
	
	public College(String college, int deptCount, int totalNoOfStudents, int totalNoOfFaculties) {
		super();
		this.college = college;
		this.deptCount = deptCount;
		this.totalNoOfStudents = totalNoOfStudents;
		this.totalNoOfFaculties = totalNoOfFaculties;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public int getDeptCount() {
		return deptCount;
	}
	public void setDeptCount(int deptCount) {
		this.deptCount = deptCount;
	}
	public int getTotalNoOfStudents() {
		return totalNoOfStudents;
	}
	public void setTotalNoOfStudents(int totalNoOfStudents) {
		this.totalNoOfStudents = totalNoOfStudents;
	}
	public int getTotalNoOfFaculties() {
		return totalNoOfFaculties;
	}
	public void setTotalNoOfFaculties(int totalNoOfFaculties) {
		this.totalNoOfFaculties = totalNoOfFaculties;
	}
	@Override
	public String toString() {
		return "College [college=" + college + ", deptCount=" + deptCount + ", totalNoOfStudents=" + totalNoOfStudents
				+ ", totalNoOfFaculties=" + totalNoOfFaculties + "]";
	}

}
