package com.heraizen.cj.college;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CollegeImpl implements collegeInterface {

	List<College> colleges = new ArrayList<College>();

	@Override
	public List<College> getAllColleges() {
		colleges = DataReader.getCollegesFromFile(
				"/home/spaneos/Documents/Anusha/JAVA-WS/Core-java/assignment/College/src/college.csv");
		return colleges;
	}

	@Override
	public List<College> getColleges(Predicate<College> p) {
		return colleges.stream().filter(p).collect(Collectors.toList());
	}

	@Override
	public Optional<College> getCollegeByName(String name) {
		return colleges.stream().filter(ele -> ele.getCollege().equals(name)).findFirst();

	}

	@Override
	public Optional<Integer> totalStudents() {
		return Optional
				.of(colleges.stream().mapToInt(ele -> ele.getTotalNoOfStudents()).reduce(0, (e1, e2) -> e1 + e2));

	}

	@Override
	public Optional<Integer> totalFaculties() {
		return Optional
				.of(colleges.stream().mapToInt(ele -> ele.getTotalNoOfFaculties()).reduce(0, (e1, e2) -> e1 + e2));
	}

	@Override
	public List<College> sort(Comparator<College> comp) {
		return colleges.stream().sorted(comp).collect(Collectors.toList());
	}

}
