package com.heraizen.cj.college;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;

public class collegeTest {

	CollegeImpl colImp = new CollegeImpl();
	List<College> colleges = new ArrayList<College>();

	@Before
	public void getAllColleges() {
		colleges = colImp.getAllColleges();
	}

	@Test
	public void getAllCollegesTest() {
		assertEquals(10, colleges.size());
	}

	@Test
	public void totalStudentsTest() {
		assertEquals(Optional.of(34500), colImp.totalStudents());
	}

	@Test
	public void totalFacultiesTest() {
		assertEquals(Optional.of(2750), colImp.totalFaculties());
	}

	@Test
	public void getCollegeByNameTest() {
		College pesit = new College("PESIT", 17, 6000, 500);
		assertEquals(Optional.of(pesit).toString(), colImp.getCollegeByName("PESIT").toString());
	}
	@Test
	public void getCollegesTest() {
		College pesit = new College("PESIT", 17, 6000, 500);
		List<College> Filteredcolleges = new ArrayList<College>();
		Filteredcolleges.add(pesit);
		assertEquals(Filteredcolleges.toString(), colImp.getColleges(colImp -> colImp.getDeptCount() == 17).toString());
	}

	@Test
	public void sortTest() {
		List<College> sortedcolleges = colImp.sort(Comparator.comparing(College::getCollege));
		colleges.stream().forEach(System.out::println);
		System.out.println("****************************");
		System.out.println("Sorted List");
		sortedcolleges.stream().forEach(System.out::println);
		
	}
}
