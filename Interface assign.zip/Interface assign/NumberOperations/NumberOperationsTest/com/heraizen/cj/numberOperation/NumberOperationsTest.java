package com.heraizen.cj.numberOperation;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class NumberOperationsTest {

	NumberOperation obj = new NumberOperation();

	@Test
	public void isPrimeTest() {
		assertEquals(true, obj.isPrime(13));
	}

	@Test
	public void isNotPrimeTest() {
		assertEquals(false, obj.isPrime(9));
	}

	@Test
	public void isPrimeNegativeTest() {
		assertEquals(false, obj.isPrime(-12));
	}

	@Test
	public void evenPrimeCheckTest() {
		assertEquals(true, obj.isPrime(2));
	}

	@Test
	public void evenNotPrimeCheckTest() {
		assertEquals(false, obj.isPrime(4));
	}

	@Test
	public void isPalindromeStrTest() {
		assertEquals(true, obj.isPalindromeStr("madam"));
	}

	@Test
	public void isNotPalindromeStrTest() {
		assertEquals(false, obj.isPalindromeStr("anu"));
	}

	// Basic Data Types

	// 1. Write a program to accept the number from the user and print the factorial
	// of that number?

	@Test
	public void factorialTest() {
		assertEquals(120, obj.factorial(5));
	}

	@Test
	public void factorialNegativeTest() {
		assertEquals(0, obj.factorial(-1));
	}

	@Test
	public void factorialOneTest() {
		assertEquals(1, obj.factorial(1));
	}

	@Test
	public void factorialZeroTest() {
		assertEquals(0, obj.factorial(0));
	}

	// 2. Write a program to list all even numbers less than or equal to the number
	// N. Take the value of N as
	// input from user.

	@Test
	public void generateEvenNosRangeTest() {
		int[] testArr = { 2, 4, 6, 8 };
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generateEvenNos(10)));
	}

	@Test
	public void generateEvenNosRangeNoEvenTest() {
		int[] testArr = {};
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generateEvenNos(1)));
	}

	@Test
	public void generateEvenNosRangeNoNegativeEvenTest() {
		int[] testArr = {};
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generateEvenNos(-10)));
	}

	// 3. Write a program to accept the lower bound and upper bound values from the
	// user and print the prime
	// numbers between lower and upper bound.

	@Test
	public void generatePrimeNosRangeTest() {
		int[] testArr = { 2, 3, 5, 7 };
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generatePrimeNos(1, 10)));
	}

	@Test
	public void generatePrimeNosNoRangeTest() {
		int[] testArr = {};
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generatePrimeNos(8, 10)));
	}

	@Test
	public void generatePrimeNoInvalidRangeTest() {
		int[] testArr = {};
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generatePrimeNos(10, 1)));
	}

	@Test
	public void generatePrimeNoNegativeRangeTest() {
		int[] testArr = { 2, 3, 5, 7 };
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generatePrimeNos(-10, 10)));
	}

	@Test
	public void generatePrimeNoNegativesRangeTest() {
		int[] testArr = {};
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.generatePrimeNos(-10, -10)));
	}

	// 4. Write a program to accept the five digit number from the user and do the
	// following
	// 4.1. Palindrome or not

	@Test
	public void isPalindromeTest() {
		assertEquals(true, obj.isPalindrome(424));
	}

	@Test
	public void isNotPalindromeTest() {
		assertEquals(false, obj.isPalindrome(46574));
	}

	// 4.2. Reverse the given number

	@Test
	public void reverseTest() {
		assertEquals(321, obj.reverse(123));
	}

	@Test
	public void reverse2Test() {
		assertEquals(32, obj.reverse(23));
	}

	@Test
	public void reverse3Test() {
		assertEquals(32, obj.reverse(23));
	}

	@Test
	public void reverseNegaTest() {
		assertEquals(32, obj.reverse(-23));
	}

	// 4.3. Sum of the digits of the given number
	@Test
	public void sumOfDigitsTest() {
		assertEquals(10, obj.sumOfDigits(1234));
	}

	@Test
	public void sumOfDigitsOneDigitTest() {
		assertEquals(1, obj.sumOfDigits(1));
	}

	@Test
	public void sumOfDigitsOneNegativeDigitTest() {
		assertEquals(10, obj.sumOfDigits(-1234));
	}

	/*
	 * 5. A) Write a program to accept a 5 digit number and a digit from the user.
	 * Find the occurrence of the given digit in the given number?
	 */

	@Test
	public void findOccurrenceOfKeyTest() {
		assertEquals(5, obj.findOccurrenceOfKey(99999, 9));
	}

	@Test
	public void findOccurrenceOfKeyNotFoundTest() {
		assertEquals(0, obj.findOccurrenceOfKey(99999, 8));
	}

	/*
	 * b)Find the sum of the digits of the number until you get a single digit sum.
	 * Ex: No is 99999 Sum should be 4+5 = 9 findSumOfDigitTillZero
	 */

	@Test
	public void findSumOfDigitTillZeroTest() {
		assertEquals(9, obj.findSumOfDigitTillZero(99999));
	}

	@Test
	public void findSumOfDigitTillZero1Test() {
		assertEquals(2, obj.findSumOfDigitTillZero(78078908));
	}

	/*
	 * 1. Write a method to accept an array and key of type integer as parameters
	 * and find two elements in the array such that their sum is equal to given key.
	 * Example: Array is: {7,3,4,2,8,9} and key = 9 Output: 0, 3 (positions)
	 */

	@Test
	public void findKeyTest() {
		int[] InpArr = { 1, 2, 3, 4, 5 }, testArr = { 0, 1 };
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.findPosInArrayWhoseSumIsEqualToKey(InpArr, 3)));
	}

	@Test
	public void findKeyAbsentTest() {
		int[] InpArr = { 1, 2, 3, 4, 5 };
		assertEquals(null, obj.findPosInArrayWhoseSumIsEqualToKey(InpArr, 20));
	}

	/*
	 * 2. Write a program to accept the string and remove the duplicate characters
	 * from the given string. Example: String: “jcljava” Output: “jclav”
	 */
	@Test
	public void removeDuplicationTest() {
		String str = "jcljavallc", testStr = "jclav";
		assertEquals(testStr, obj.removeDuplication(str));
	}

	@Test
	public void removeDuplicationNoDuplicantsTest() {
		String str = "jclav", testStr = "jclav";
		assertEquals(testStr, obj.removeDuplication(str));
	}
	/*
	 * 3. Write a program to find the sum of first ‘N’ Fibonacci series. Example: If
	 * N= 6, the series is (0+1+1+2+3+5); Sum = 12
	 */

	@Test
	public void fibonacciTest() {
		assertEquals(33, obj.fibonacci(8));
	}

	@Test
	public void fibonacciNegativeTest() {
		assertEquals(0, obj.fibonacci(-8));
	}

	@Test
	public void fibonacciOneTest() {
		assertEquals(1, obj.fibonacci(1));
	}

	//
	// 4.
	// Write a program to find the Greatest Common Divisor (GCD) of three numbers.
	// Example:
	// Three numbers: 35, 42, 63; GCD = 7
	@Test
	public void gcdOfThreeNoTest() {
		assertEquals(7, obj.gcdOfThreeNo(35, 42, 63));
	}

	@Test
	public void gcdOfThreeNo1Test() {
		assertEquals(1, obj.gcdOfThreeNo(1, 1, 1));
	}

	@Test
	public void gcdOfThreeNo0Test() {
		assertEquals(0, obj.gcdOfThreeNo(0, 0, 0));
	}

	@Test
	public void gcdOfThreeNo11Test() {
		assertEquals(1, obj.gcdOfThreeNo(3, 5, 7));
	}

//	5.
//	Write a program to find the sum of positive numbers and negative numbers in the given M x N
//	matrix.
//	Example:
//	In a given matrix:
//	1 -2 3
//	2 5 -8
//	4 6 -4
//	The sum of +ve numbers: 21
//	The Sum of –ve numbers: -14
	@Test
	public void sumOfPositiveAndNegativeNoTest() {
		int[][] mat = { { 1, -2, 3 }, { 2, 5, -8 }, { 4, 6, -4 } };
		int[] test = { 21, -14 };
		assertEquals(Arrays.toString(test), Arrays.toString(obj.sumOfPositiveAndNegativeNo(mat)));
	}

	// 6.
	// In the following array, consecutive numbers are stored but 1 number is
	// missing. These numbers
	// are not stored in any particular order. Write a program to determine the
	// missing number.
	// Array : [1,2,5,3,6,7,9,8] missing value is: 4
	@Test
	public void missingNumbersTest() {
		int[] inpArr = { 1, 2, 5, 3, 6, 7, 9, 8 };
		String test = "4";
		assertEquals(test, obj.missingNumbers(inpArr));
	}

	@Test
	public void missingNumbers2Test() {
		int[] inpArr = { 1, 2, 5, 3, 7, 9, 8 };
		String test = "4,6";
		assertEquals(test, obj.missingNumbers(inpArr));
	}

	// 7. Write a program to generate first 'N' prime numbers.
	// Example:
	// If N = 5 then output should be: 2, 3, 5, 7, 11

	@Test
	public void generatePrimeNosFirstNTest() {
		int[] test = { 2, 3, 5, 7, 11 };
		assertEquals(Arrays.toString(test), Arrays.toString(obj.generatePrimeNosFirstN(5)));
	}
	
	//	8. Write a program to accept a number from the user and count the number of prime digits in the
	//	given number.Example:
	//	If number = 23897 then output should be: “Number of prime digits in 23897 is: 3”
	@Test
	public void primeCountTest() {
		assertEquals(3, obj.primeCount(23897));
	}
	
	
	//	9. Write a program to count the number of words in the given string.
	//	Input String: "core java java core advanced java"
	//	Output: 6
	//	
	
	@Test
	public void wordCountTest() {
		assertEquals(6, obj.wordCount("core java java core advanced java"));
	}
	

}
