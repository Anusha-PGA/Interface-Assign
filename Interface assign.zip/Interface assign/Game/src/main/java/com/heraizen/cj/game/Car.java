package com.heraizen.cj.game;

public class Car implements Game{

	@Override
	public String play() {
		return "You are driving car";
	}

}
