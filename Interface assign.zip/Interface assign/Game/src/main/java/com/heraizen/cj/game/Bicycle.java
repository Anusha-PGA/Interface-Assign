package com.heraizen.cj.game;

public class Bicycle implements Game{

	@Override
	public String play() {

		return "You are riding Bicycle";
	}
	

}
