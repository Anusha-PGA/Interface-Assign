package com.heraizen.cj.game;

public class Bike implements Game{

	@Override
	public String play() {

		return "You are riding a Bike";
	}

}
