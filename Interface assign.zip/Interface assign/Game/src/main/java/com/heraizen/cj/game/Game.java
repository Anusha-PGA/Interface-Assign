package com.heraizen.cj.game;

public interface Game {
	
	public default String start() {
		String str= getClass().getSimpleName();
		return str + " Started";

	}

	public String play();

	public default String stop() {
		String str= getClass().getSimpleName();
		return str + " Stopped";

	}

}
