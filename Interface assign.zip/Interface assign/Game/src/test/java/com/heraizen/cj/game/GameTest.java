package com.heraizen.cj.game;

import org.junit.Test;

public class GameTest {
	Game obj;
	@Test
	public void polymorphicBehaviorTest() {
		int randomInt;
		Game obj;
		for (int i = 0; i < 10; i++) {
			randomInt = (int) (3.0 * Math.random());
			if(randomInt==0)
				obj = new Car();
			else if(randomInt==1)
				obj = new Bike();
			else
				obj = new Bicycle();
			System.out.println(obj.start());
			System.out.println(obj.play());
			System.out.println(obj.stop());
		}
	}
}
