package com.heraizen.cj.remote;

public interface RemoteControl {

	public boolean powerOnOff();
	int volumeUp(int increment); 
	int volumeDown(int decrement); 
	public void mute();

}
