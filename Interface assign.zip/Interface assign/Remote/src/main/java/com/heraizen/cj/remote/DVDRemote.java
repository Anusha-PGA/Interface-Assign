package com.heraizen.cj.remote;

public class DVDRemote implements RemoteControl {
	final int MAX_SOUND = 100;
	final int MIN_SOUND = 0;
	int currentSound = 12;
	boolean OnOff = false;
	boolean muteOnOff = false;

	@Override
	public boolean powerOnOff() {
		OnOff = !OnOff;
		return OnOff;
	}

	@Override
	public int volumeUp(int increment) {
		if (currentSound + increment < 100)
			currentSound += increment;
		else
			currentSound = 100;
		return currentSound;
	}

	@Override
	public int volumeDown(int decrement) {
		if (currentSound - decrement > 0)
			currentSound -= decrement;
		else
			currentSound = 0;
		return currentSound;
	}

	@Override
	public void mute() {
		muteOnOff=!muteOnOff;

	}

}
