package com.heraizen.cj.remote;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class remoteTest {
	
	DVDRemote dvd = new DVDRemote();
	TVRemote tv = new TVRemote();
	@Test
	public void onOffDVDTest(){
		assertEquals(true, dvd.powerOnOff());
		assertEquals(false, dvd.powerOnOff());
	}
	
	@Test
	public void onOffTVTest(){
		assertEquals(true, tv.powerOnOff());
		assertEquals(false, tv.powerOnOff());
	}
	
	@Test
	public void onOffVolumeupDVDTest(){
		dvd.currentSound=12;
		assertEquals(24, dvd.volumeUp(12));
		assertEquals(100, dvd.volumeUp(123));
	}

	@Test
	public void onOffVolumeupTVTest(){
		tv.currentSound=12;
		assertEquals(24, tv.volumeUp(12));
		assertEquals(100, tv.volumeUp(123));
	}
	@Test
	public void onOffVolumeDownDVDTest(){
		dvd.currentSound=12;
		assertEquals(10, dvd.volumeDown(2));
		assertEquals(0, dvd.volumeDown(12));
	}

	@Test
	public void onOffVolumeDownTVTest(){
		tv.currentSound=12;
		assertEquals(10, tv.volumeDown(2));
		assertEquals(0, tv.volumeDown(12));
	}
	@Test
	public void muteDVDTest(){
		dvd.OnOff=true;
		dvd.mute();
		assertEquals(true,dvd.muteOnOff );
		assertEquals(false,dvd.muteOnOff );
	}

	@Test
	public void muteTVTest(){
		dvd.OnOff=true;
		dvd.mute();
		assertEquals(true,dvd.muteOnOff );
		assertEquals(false,dvd.muteOnOff );
	}
}
