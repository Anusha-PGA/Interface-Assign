package com.heraizen.cj.instrument;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class InstrumentTest {
	@Test
	public void PianoPlayTest() {
		Piano piano = new Piano();
		assertEquals("Piano is playing pee peee peee", piano.play());
	}

	@Test
	public void FlutePlayTest() {
		Flute flute = new Flute();
		assertEquals("Flute is playing toot toot toot toot", flute.play());
	}

	@Test
	public void GuitarPlayTest() {
		Guitar guitar = new Guitar();
		assertEquals("Guitar is playing tin tin tin tin", guitar.play());
	}

	@Test
	public void polymorphicBehaviorTest() {
		int randomInt;
		Instrument obj;
		for (int i = 0; i < 10; i++) {
			randomInt = (int) (3.0 * Math.random());
			if(randomInt==0)
				obj = new Piano();
			else if(randomInt==1)
				obj = new Flute();
			else
				obj = new Guitar();
			System.out.println(obj.play());
		}
	}
}
