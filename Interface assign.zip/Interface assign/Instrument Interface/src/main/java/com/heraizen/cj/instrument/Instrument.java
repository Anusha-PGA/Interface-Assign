package com.heraizen.cj.instrument;

public interface Instrument {
	public String play();
}
