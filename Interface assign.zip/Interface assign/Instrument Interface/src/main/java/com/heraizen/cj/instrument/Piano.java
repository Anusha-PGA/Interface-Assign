package com.heraizen.cj.instrument;

public class Piano implements Instrument{

	@Override
	public String play() {
		return "Piano is playing pee peee peee";
	}

}
