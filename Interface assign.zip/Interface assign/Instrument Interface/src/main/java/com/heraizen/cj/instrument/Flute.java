package com.heraizen.cj.instrument;

public class Flute implements Instrument{

	@Override
	public String play() {
		return "Flute is playing toot toot toot toot";
	}

}
