package com.heraizen.cj.instrument;

public class Guitar implements Instrument {

	@Override
	public String play() {
		return "Guitar is playing tin tin tin tin";
	}

}
